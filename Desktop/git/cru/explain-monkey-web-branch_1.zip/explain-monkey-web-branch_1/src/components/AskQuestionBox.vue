<template>
  <div>
    <div>
      <div
        class="row align-items-center bg-light-grey black border-top-radius-20 padding-top-16 padding-bottom-16 padding-left-24 padding-right-24"
      >
        <img class="col-2" src="../assets/images/hill.png" />
        <div class="col-10 text-center">
          <span>120 experts are available</span>
          <i class="fa fa-circle font-size-10 green"></i>
        </div>
      </div>
      <div class="bg-white border-bottom-radius-20 padding-20">
        <textarea
          class="input-textarea"
          rows="14"
          placeholder="Type your question here"
        />
        <br />
        <br />
        <button class="btn btn-primary"><b>Get an answer</b></button>
        <br />
        <br />
      </div>
    </div>
    <p class="text-center padding-top-14">
      <b>186,675</b>&nbsp;<span>Questions answered</span>
    </p>
  </div>
</template>

<script>
export default {};
</script>

<style scoped></style>
