<template>
  <div class="bg-light-black white">
    <div class="content-container">
      <br />
      <br />
      <!-- <br /> -->
      <div class="row">
        <div class="col-sm-4">
          <h2 class="padding-10">Browse Categories</h2>
          <p class="padding-10 cursor-pointer">Meet the experts</p>
          <p class="padding-10 cursor-pointer">Refer an expert</p>
          <p class="padding-10 cursor-pointer">Articles</p>
          <p class="padding-10 cursor-pointer">Register</p>
        </div>
        <div class="col-sm-4">
          <h2 class="padding-10">About us</h2>
          <p class="padding-10 cursor-pointer">Company Information</p>
          <p class="padding-10 cursor-pointer">Jobs</p>
          <p class="padding-10 cursor-pointer">Fraud awareness</p>
          <p class="padding-10 cursor-pointer">Cookies Policy</p>
        </div>
        <div class="col-sm-4 row">
          <div class="col-xl-6">
            <h2 class="padding-10 cursor-pointer">Help & Support</h2>
            <p class="padding-10 cursor-pointer">FAQ</p>
            <p class="padding-10 cursor-pointer">Contact Us</p>
            <p class="padding-10 cursor-pointer">Partners & Affiliates</p>
          </div>
          <div class="col-xl-6 padding-10 row">
            <span class="col-md-4"> <img src="../assets/svg/twitter.svg" width="60"/></span>
            <span class="col-md-4"> <img src="../assets/svg/facebook.svg" width="60"/></span>
            <span class="col-md-4"> <img src="../assets/svg/instagram.svg" width="60"/></span>
          </div>
        </div>
      </div>
      <br />
      <div class="row">
        <span class="col text-center">Copyright 2020. ExplainMonkey All rights reserved.</span>
      </div>
      <br />
      <br />
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
