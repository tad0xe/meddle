<template>
  <div>
    <div class="content-container padding-right-10 padding-right-md-20">
      <h1
        class="font-size-20 font-size-md-32 padding-left-0 padding-left-md-60"
      >
        Testimonials
      </h1>
      <div class="row">
        <div
          class="col-lg-3 padding-left-0 padding-right-0 padding-top-0 padding-bottom-30 padding-left-md-60 padding-right-md-60 padding-top-md-60 padding-bottom-md-60"
        >
          <p class="font-size-14 font-size-md-30">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit.
          </p>
          <br class="d-block-hidden-md" />
          <br class="d-block-hidden-md" />
          <br />
          <button
            class="btn btn-primary bg-white font-size-14 font-size-md-20 border-black padding-left-10 padding-right-10 padding-top-18 padding-bottom-18 padding-left-md-30 padding-right-md-30 padding-top-md-30 padding-bottom-md-30"
          >
            Read All
          </button>
        </div>
        <div class="row col-lg-9">
          <div class="col-lg-4 d-block-hidden-lg">
            <div class="row align-items-end home-testimonial-row-1-image">
              <span class="font-size-25 white padding-20 text-center"
                >Victoria</span
              >
            </div>
          </div>
          <div class="col-lg-4">
            <div class="row align-items-end home-testimonial-row-2-image">
              <div
                class="bg-light-green white padding-left-20 padding-right-20 padding-top-20 padding-bottom-20"
              >
                <span class="font-size-25 white">Tom says</span>
                <p>
                  Tom says Lorem ipsum dolor sit amet, consectetur adipiscing
                  elit. Curabitur hendrerit mattis
                </p>
                <button
                  class="btn btn-primary bg-light-green border-white white font-size-20"
                >
                  Read More
                </button>
              </div>
            </div>
          </div>
          <div class="col-lg-4 d-block-hidden-lg">
            <div
              class="row align-items-end text-center home-testimonial-row-3-image"
            >
              <span
                class="font-size-25 padding-left-20 padding-right-20 padding-top-20 padding-bottom-20 white"
                >Megan</span
              >
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped></style>
