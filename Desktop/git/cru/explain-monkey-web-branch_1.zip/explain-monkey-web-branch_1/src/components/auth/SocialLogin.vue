<template>
  <div>
    <div class="d-flex bg-green white align-items-center border-radius-10 border-1 border-color-green">
      <i class="fa fa-facebook bg-red border-top-left-radius-10 border-bottom-left-radius-10 font-size-24 padding-top-8 padding-bottom-8 padding-left-18 padding-right-18"></i>
      <div class="flex-grow-1 font-size-16 paddinga-6 text-center">Login with Facebook</div>
    </div>
    <br />
    <div class="d-flex bg-green white align-items-center border-radius-10 border-1 border-color-green">
      <i class="fa fa-google bg-red border-top-left-radius-10 border-bottom-left-radius-10 font-size-24 padding-top-8 padding-bottom-8 padding-left-16 padding-right-16"></i>
      <div class="flex-grow-1 font-size-16 paddinga-6 text-center">Login with Google</div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped></style>
