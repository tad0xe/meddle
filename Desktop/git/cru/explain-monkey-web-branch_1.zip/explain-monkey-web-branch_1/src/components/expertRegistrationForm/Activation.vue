<template>
  <div>
    <form class="content-container">
 <div class="d-flex justify-content-evenly ">
        <div class="margin-top-60">
 <div class="exp-reg-check " ></div>
        </div>
        <div class="margin-top-60">
          <p>Activation Status: PENDING</p>
          <br>
          <BUtton class=" bg-white  border-radius-8 border-color-red padding-10 red border-1 margin-left-20">Delete application</BUtton>
        </div>

      </div>

        <p class="text-center padding-bottom-50">Thanks for completing your registration as an expert. When the application review is complete, we will contact you via email with a link to complete your ID verification process, and if necessary, for you to submit more information for background checks.</p>
    </form>
  </div>
</template>

<script>
export default {
  components: {
  },

  methods: {
  },
};
</script>

<style scoped></style>
