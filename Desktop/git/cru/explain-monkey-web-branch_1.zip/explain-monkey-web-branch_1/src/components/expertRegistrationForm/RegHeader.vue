<template>
  <div>
    <div class="row">
      <!-- <hr
        class="reg-header-line"
      /> -->

      <div class="row col-11">
        <div class="row col-3">
          <span class="reg-header-circle col-4">1</span> <br />
          <hr class="col-8 reg-header-line" />
          <span class="font-size-9 font-size-md-14 font-size-lg-16"
            >Sign Up</span
          >
        </div>
        <div class="row col-3">
          <span class="reg-header-circle col-4">2</span> <br />
          <hr class="col-8 reg-header-line" />
          <span class="font-size-9 font-size-md-14 font-size-lg-16"
            >Personal Information</span
          >
        </div>
        <div class="row col-3">
          <span class="reg-header-circle col-4">3</span> <br />
          <hr class="col-8 reg-header-line" />
          <span class="font-size-9 font-size-md-14 font-size-lg-16"
            >Professional Details</span
          >
        </div>
        <div class="row col-3">
          <span class="reg-header-circle col-4">4</span> <br />
          <hr class="col-8 reg-header-line" />
          <span class="font-size-9 font-size-md-14 font-size-lg-16"
            >References</span
          >
        </div>
      </div>
      <div class="col-1 row">
        <span class="reg-header-circle col">5</span> <br />
        <span class="font-size-9 font-size-md-14 font-size-lg-16"
          >Activation</span
        >
      </div>
    </div>
  </div>
</template>

<script>
export default {
  components: {},

  methods: {},
};
</script>

<style scoped></style>
