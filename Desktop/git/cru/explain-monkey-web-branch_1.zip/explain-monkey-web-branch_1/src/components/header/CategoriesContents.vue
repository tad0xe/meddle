<template>
  <div>
    <div class="row">
      <div class="row col-md-6 padding-top-2 padding-bottom-2 bg-white">
        <div class="row col-lg-6 padding-top-2 padding-bottom-2">
          <div class="col-6">
            <p>
              <b class="nav-drop-down-item padding-left-10 padding-right-10">Medical Pros</b>
            </p>
            <div class="font-size-13 padding-left-10 padding-right-10">
              <p class="nav-drop-down-item">Doctors</p>
              <p class="nav-drop-down-item">Nurses</p>
              <p class="nav-drop-down-item">Pharmacists</p>
              <p class="nav-drop-down-item">Dentists</p>
              <p class="nav-drop-down-item">Medical Lab</p>
              <p class="nav-drop-down-item">Dentists</p>
            </div>
            <p class="nav-drop-down-item padding-left-10 padding-right-10 font-size-11 green">
              See more
            </p>
          </div>
          <div class="col-6">
            <p>
              <b class="nav-drop-down-item padding-left-10 padding-right-10">lawyers</b>
            </p>
            <div
              class="font-size-13 padding-left-10 padding-right-10 border-left-2 border-color-light-grey"
            >
              <p class="nav-drop-down-item">Property Law</p>
              <p class="nav-drop-down-item">Criminal Law</p>
              <p class="nav-drop-down-item">Business Law</p>
              <p class="nav-drop-down-item">Real Estate Law</p>
              <p class="nav-drop-down-item">Consumaer Protection Law</p>
              <p class="nav-drop-down-item">Employment Law</p>
            </div>
            <p class="nav-drop-down-item padding-left-10 padding-right-10 font-size-11 green">
              See more
            </p>
          </div>
        </div>
        <div class="row col-lg-6 padding-top-2 padding-bottom-2">
          <div class="col-6">
            <p><b class="nav-drop-down-item padding-left-10 padding-right-10">Vets</b></p>
            <div
              class="font-size-13 padding-left-10 padding-right-10 border-left-2 border-color-light-grey"
            >
              <p class="nav-drop-down-item">Poultry</p>
              <p class="nav-drop-down-item">Dogs</p>
              <p class="nav-drop-down-item">Cats</p>
              <p class="nav-drop-down-item">Cattle</p>
              <p class="nav-drop-down-item">Fish</p>
              <p class="nav-drop-down-item">Goats</p>
            </div>
            <p class="nav-drop-down-item padding-left-10 padding-right-10 font-size-11 green">
              See more
            </p>
          </div>
          <div class="col-6">
            <p>
              <b class="nav-drop-down-item padding-left-10 padding-right-10">Mechanics</b>
            </p>
            <div
              class="font-size-13 padding-left-10 padding-right-10 border-left-2 border-color-light-grey"
            >
              <p class="nav-drop-down-item">BWM</p>
              <p class="nav-drop-down-item">Mercedes Benz</p>
              <p class="nav-drop-down-item">Audi</p>
              <p class="nav-drop-down-item">Volkswagen</p>
              <p class="nav-drop-down-item">Toyota</p>
              <p class="nav-drop-down-item">Honda</p>
            </div>
            <p class="nav-drop-down-item padding-left-10 padding-right-10 font-size-11 green">
              See more
            </p>
          </div>
        </div>
      </div>
      <div class="row col-md-6 padding-top-2 padding-bottom-2">
        <div class="row col-lg-6 padding-top-2 padding-bottom-2">
          <div class="col-6">
            <p>
              <b class="nav-drop-down-item padding-left-10 padding-right-10">Electricians</b>
            </p>
            <div
              class="font-size-13 padding-left-10 padding-right-10 border-left-2 border-color-light-grey"
            >
              <p class="nav-drop-down-item">Appliances</p>
              <p class="nav-drop-down-item">Electrical</p>
              <p class="nav-drop-down-item">Mobile Phones</p>
              <p class="nav-drop-down-item">Office Equipment</p>
              <p class="nav-drop-down-item">Kitchen Equipment</p>
              <p class="nav-drop-down-item">Honda</p>
            </div>
            <p class="nav-drop-down-item padding-left-10 padding-right-10 font-size-11 green">
              See more
            </p>
          </div>
          <div class="col-6">
            <p>
              <b class="nav-drop-down-item padding-left-10 padding-right-10">Tutors</b>
            </p>
            <div
              class="font-size-13 padding-left-10 padding-right-10 border-left-2 border-color-light-grey"
            >
              <p class="nav-drop-down-item">Mathematics</p>
              <p class="nav-drop-down-item">English Language</p>
              <p class="nav-drop-down-item">Physics</p>
              <p class="nav-drop-down-item">Chemistry</p>
              <p class="nav-drop-down-item">Biology</p>
              <p class="nav-drop-down-item">Literature</p>
            </div>
            <p class="nav-drop-down-item padding-left-10 padding-right-10 font-size-11 green">
              See more
            </p>
          </div>
        </div>
        <div class="row col-lg-6 padding-top-2 padding-bottom-2">
          <div class="col-6">
            <p>
              <b class="nav-drop-down-item padding-left-10 padding-right-10">Psychologists</b>
            </p>
            <div
              class="font-size-13 padding-left-10 padding-right-10 border-left-2 border-color-light-grey"
            >
              <p class="nav-drop-down-item">Depression</p>
              <p class="nav-drop-down-item">Stress</p>
              <p class="nav-drop-down-item">Anxiety</p>
              <p class="nav-drop-down-item">Paranoia</p>
              <p class="nav-drop-down-item">Mental Disorder</p>
              <p class="nav-drop-down-item">Inferiority Complex</p>
            </div>
            <p class="nav-drop-down-item padding-left-10 padding-right-10 font-size-11 green">
              See more
            </p>
          </div>
          <div
            class="col-6 nav-item d-flex flex-column align-items-center justify-content-center"
          >
            <img
              class="padding-bottom-5 padding-bottom-md-30"
              src="../../assets/svg/right-arrow.svg"
              width="45"
            />
            <p><b class="nav-drop-down-item font-size-18">Other Categories</b></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
