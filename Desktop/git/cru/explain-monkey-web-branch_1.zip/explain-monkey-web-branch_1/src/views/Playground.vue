<template>
  <div class="content-container">
    <div class="d-flex justify-content-end justify-content-between">
      <div v-if="currentScreenWidth > '768'"></div>
      <div
        class="bg-white margin-bottom-8 padding-10 border-radius-6 margin-top-36"
        v-if="currentScreenWidth < '768'"
      >
        <div class="dashboard-nav-icon"></div>
        <div class="margin-top-2 dashboard-nav-icon"></div>
        <div class="dashboard-nav-icon margin-top-2"></div>
      </div>
    </div>
    <div class="row d-flex justify-content-between padding-top-70">
      <div class="d-flex">
        <div v-if="currentScreenWidth < '768'">
          <button
            class="bg-white border-radius-8 border-color-green padding-10 green border-1 margin-bottom-10"
          >
            See Recent Activities
          </button>
          <h4
            class="padding-bottom-10 padding-left-2"
            v-if="currentScreenWidth < '768'"
          >
            Ask a Question
          </h4>
        </div>
      </div>
      <div class="row">
        <div class="col-md-8">
          <div class="border-radius-10 bg-white padding-right-150-lg">
            <div class="padding-left-20 padding-right-50">
              <h3 v-if="currentScreenWidth > '768'">Ask a Question</h3>
              <br />
              <br />
              <div class="d-flex">
                <h4 class="padding-top-10 margin-right-4">Select Category</h4>
                <select class="form-control">
                  <option>Select</option>
                  <option></option>
                </select>
              </div>
              <br />
              <div class="d-flex">
                <h4 class="padding-right-30">Select Field</h4>
                <select class="form-control">
                  <option>Select</option>
                  <option></option>
                </select>
              </div>
              <br />
              <br />
              <textarea
                class="input-textarea"
                rows="14"
                placeholder="Type your question here"
              ></textarea>
              <br />
              <div class="d-flex justify-content-end">
                <button
                  class="margin-top-10 margin-bottom-10 border-0 border-radius-6 padding-10 bg-green"
                >
                  Submit
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4 padding-left-20 float-end">
          <div class="d-flex">
            <div class="bg-green padding-20">10</div>
            <div class="margin-left-20 padding-20 bg-green">10</div>
            <div class="margin-left-20 padding-20 bg-green">10</div>
            <div class="margin-left-20 padding-20 bg-green">10</div>
            <div class="bg-green padding-20 margin-left-20">10</div>
          </div>
          <div class="font-size-9 justify-content-center">
            <h2>My Recent Questions</h2>
            <div class="bg-black padding-right-14">
              <h4>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor?
              </h4>
            </div>
            <div>
              orem ipsum dolor sit ame10t, consectetur adipiscing elit, sed do
              eiusmod tempor?
            </div>
            <div>
              orem ipsum dolor s10it amet, consectetur adipiscing elit, sed do
              eiusmod tempor?
            </div>
            <div>
              orem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor?
            </div>
          </div>
        </div>
      </div>
    </div>
    <div
      class="d-flex margin-top-20 margin-left-30"
      v-if="currentScreenWidth > '768'"
    >
      <div>
        <h4>RECENT NOTIFICATIONS</h4>
        <div>
          <h4>james Replied</h4>
          <p>22 secs ago</p>
        </div>
        <div>
          <h4>james Replied</h4>
          <p>22 secs ago</p>
        </div>
        <div>
          <h4>james Replied</h4>
          <p>22 secs ago</p>
        </div>
      </div>
      <div class="padding-left-30">
        <h4>RECENT NOTIFICATIONS</h4>
        <div>
          <h4>james Replied</h4>
          <p>22 secs ago</p>
        </div>
        <div>
          <h4>james Replied</h4>
          <p>22 secs ago</p>
        </div>
        <div>
          <h4>james Replied</h4>
          <p>22 secs ago</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";

export default {
  computed: {
    ...mapState({
      currentScreenWidth: (state) => state.utilities.currentScreenWidth,
    }),
  },
};
</script>

<style scoped>
</style>
